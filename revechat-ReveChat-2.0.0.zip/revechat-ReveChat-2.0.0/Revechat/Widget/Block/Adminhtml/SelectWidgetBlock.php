<?php
namespace  Revechat\Widget\Block\Adminhtml;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\App\ObjectManager;
use Revechat\Widget\Model\PostFactory;
use Psr\Log\LoggerInterface;

class SelectWidgetBlock extends \Magento\Framework\View\Element\Template
{

    protected $_logger;

    public function __construct(Context $context,
                                LoggerInterface $logger,
                                PostFactory $modelFactory)
    {
        $this->_modelFactory = $modelFactory;
        parent::__construct($context);
        $this->_logger = $logger;
    }

    public function getAccountId() {

        $id = 1;
        $objectManager = ObjectManager::getInstance();
        $model = $objectManager->create('\Revechat\Widget\Model\PostFactory')->load($id);
        $this->_logger->info('SelectWidgetBlock.php: $model->getAccountId(): '. $model->getAccountId());
        return $model->getAccountId();
    }

}
