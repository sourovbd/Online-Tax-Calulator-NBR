<?php

namespace Revechat\Widget\Block;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\View\Element\Template;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\ObjectManager;
use Revechat\Widget\Model\PostFactory;
use Psr\Log\LoggerInterface;


class Embed extends Template
{
    protected $_logger;

    public function __construct(
        Context $context,
        PostFactory $modelFactory,
        LoggerInterface $logger,
        ResourceConnection $resourceConnection
    )
    {
        $this->_modelFactory = $modelFactory;
        parent::__construct($context);
        $this->_logger = $logger;
        $this->resourceConnection = $resourceConnection;
    }

    public function getAccId() {
        $id = 1;
        $objectManager = ObjectManager::getInstance();
        $model = $objectManager->create('\Revechat\Widget\Model\PostFactory')->load($id);
        $this->_logger->info('Embed.php: $model->getAccountId(): '.$model->getAccountId());
        return $model->getAccountId();
    }

}