<?php
namespace Revechat\Widget\Controller\Adminhtml\SelectWidget;

use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Action;
use Revechat\Widget\Model\PostFactory;
use Psr\Log\LoggerInterface;


class Index extends Action
{
    protected $resultJsonFactory;
    protected $_pageFactory;
    protected $_logger;
    protected $_modelFactory;
    public function __construct(Context $context,
                                PageFactory $pageFactory,
                                PostFactory $modelFactory,
                                JsonFactory $resultJsonFactory,
                                LoggerInterface $logger) {

        $this->_pageFactory = $pageFactory;
        $this->_modelFactory = $modelFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_logger = $logger;
        return parent::__construct($context);
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Revechat_Widget::revechat_choose_widget');
    }

    public function execute()
    {
        $response = $this->resultJsonFactory->create();
        $response->setHeader('Content-type', 'application/json');

        $id = 1;
        $objectManager = ObjectManager::getInstance();
        $model = $objectManager->create('\Revechat\Widget\Model\PostFactory')->load($id);

        if($this->getRequest()->getParam('revechat_remove')) {

            $model->setAccountId("");

        } else {

            if(($this->getRequest()->getParam('revechat_aid')!="")) {

                $revechat_aid = $this->getRequest()->getParam('revechat_aid');
                $this->_logger->info('revechat_aid: '. $revechat_aid);

                $model->setAccountId($revechat_aid);
                $this->_logger->info('$model->getAccountId(): '. $model->getAccountId());
            }
        }

        $model->save();
        $response->setData(['success' => TRUE]);

        return $this->_pageFactory->create();

    }
}