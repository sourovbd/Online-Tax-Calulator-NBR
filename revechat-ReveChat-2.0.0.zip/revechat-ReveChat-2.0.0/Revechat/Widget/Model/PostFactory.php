<?php

namespace Revechat\Widget\Model;

use Magento\Framework\Model\AbstractModel;
use Psr\Log\LoggerInterface;

class PostFactory extends AbstractModel
{
    protected function _construct()
    {
        $this->_init('Revechat\Widget\Model\ResourceModel\Post');
    }

    public function loadByAccountId($id)
    {
        return $this->getCollection()
            ->addFieldToFilter('account_id', $id)
            ->getFirstItem();
    }
}