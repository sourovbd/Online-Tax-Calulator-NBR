<?php

namespace Revechat\Widget\Model\ResourceModel\Post;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Psr\Log\LoggerInterface;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'account_id';
    protected $_eventPrefix = 'revechat_widget_collection';
    protected $_eventObject = 'account_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Revechat\Widget\Model\PostFactory', 'Revechat\Widget\Model\ResourceModel\Post');
    }

}