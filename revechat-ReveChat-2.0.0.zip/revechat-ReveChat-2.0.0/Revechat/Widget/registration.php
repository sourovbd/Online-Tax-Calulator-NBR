<?php

//This will register your module to magento 2
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Revechat_Widget',
    __DIR__
);